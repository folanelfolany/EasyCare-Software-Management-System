<?php
require_once('../config/config.php');

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $userType = $_POST['user_type'];

    // Perform validation and sanitization on the input

    // Create the appropriate SQL query based on the user type
    switch ($userType) {
        case 'doctor':
            $table = 'doctor_credentials';
            $redirectPage = '../controller/manage.php';
            break;
        case 'admin':
            $table = 'admin_credentials';
            $redirectPage = '../view/index.php';
            break;
        case 'patient':
            $table = 'patient_credentials';
            $redirectPage = '../view/appointment.php';
            break;
        case 'staff':
            $table = 'staff_credentials';
            $redirectPage = '../view/index.php';
            break;
        default:
            // Invalid user type
            header('Location:app.php');
            exit();
    }

    // Prepare the query to check credentials
    $query = "SELECT * FROM $table WHERE username = '$username' AND password = '$password'";

    // Execute the query
    $result = mysqli_query($con, $query);

    // Check if the query was successful
    if ($result && mysqli_num_rows($result) > 0) {
        // Valid credentials, set session variables and redirect to the appropriate page
        $_SESSION['user'] = $username;

        // Redirect to the appropriate page based on the user type
        header("Location: $redirectPage");
        exit();
    } else {
        // Invalid credentials, redirect back to the login page
        header('Location:app.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Welcome - Login </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../public/style.css">
</head>
<body>
    <div class="container">
        <form method="POST" action="app.php">
            <h2>Welcome!<Br>EasyCare Login</h2>
            <select name="user_type">
                <option value="staff">Staff</option>
                <option value="doctor">Doctor</option>
                <option value="patient">Patient</option>
                <option value="admin">Admin</option>
            </select>
            <br>
            <input type="text" name="username" placeholder="Username">
            <br>
            <input type="password" name="password" placeholder="Password">
            <br>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
