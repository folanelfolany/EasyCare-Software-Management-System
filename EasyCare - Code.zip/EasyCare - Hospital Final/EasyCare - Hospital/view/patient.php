<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Perform validation and sanitization on the input

    // Check credentials and redirect to home.php if successful
    // Add your patient login logic here

    // Example redirect:
    header('Location: appointment.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Patient Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../public/main.css">
</head>
<body>
    <div class="container">
        <form method="POST" action="patient.php">
            <h2>EasyCare Patient Login</h2>
            <label>Username</label>
            <br>
            <input type="text" name="username" placeholder="Username">
            <br>
            <label>Password</label>
            <br>
            <input type="password" name="password" placeholder="Password">
            <br>
            <center>
                <input type="submit" value="Login">
            </center>
        </form>
    </div>
</body>
</html>
