<?php
require_once '../config/config.php';
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve appointment details from the form
    $patientID = $_POST['patient_id'];
    $doctorID = $_POST['doctor_id'];
    $appointmentDate = $_POST['appointment_date'];
    $appointmentTime = $_POST['appointment_time'];
    $status = 'Pending'; // Default status for a new appointment

    // Perform validation and sanitization on the input

    // Add code to insert the appointment into the database
    // You may need to adjust the table name and column names based on your database structure
    $query = "INSERT INTO appointment (PatientID, DoctorID, AppointmentDate, AppointmentTime, Status)
              VALUES ('$patientID', '$doctorID', '$appointmentDate', '$appointmentTime', '$status')";

    // Execute the query and handle the result accordingly
    $result = mysqli_query($con, $query);
    if ($result) {
        // Appointment booked successfully
        // You can redirect the user to a success page or perform any other action
        // For now, we'll display a success message
        echo '<p>Appointment booked successfully!</p>';
    } else {
        // Error occurred while booking the appointment
        // You can redirect the user to an error page or perform any other action
        // For now, we'll display an error message
        echo '<p>Error: Unable to book the appointment. Please try again later.</p>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Appointment</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../public/main.css">
</head>
<body>
    <div class="container">
        <h2>Welcome to EasyCare Hospital</h2>
        <p>We are delighted to have you as our new patient! Please book an appointment below:</p>
        
        <form method="POST" action="appointment.php">
            <h3>Book Appointment</h3>
            <label>Patient ID:</label>
            <input type="text" name="patient_id" placeholder="Patient ID" required>
            <br>
            <label>Doctor ID:</label>
            <input type="text" name="doctor_id" placeholder="Doctor ID" required>
            <br>
            <label>Appointment Date:</label>
            <input type="date" name="appointment_date" required>
            <br>
            <label>Appointment Time:</label>
            <input type="time" name="appointment_time" required>
            <br>
            <input type="submit" value="Book Appointment">
        </form>
    </div>
</body>
</html>
