<?php
session_start();
require_once('../config/config.php');

if (!isset($_GET['id'])) {
    header('location:index.php');
    exit();
}

if (isset($_POST['submit'])) {
    $error_msg = [];

    if (
        isset($_POST['ID'], $_POST['UserID'], $_POST['MedicalHistory'], $_POST['CurrentStatus'], $_POST['Allergies'], $_POST['InsuranceDetails'], $_POST['AdmissionDate'])
        && !empty($_POST['ID'])
        && !empty($_POST['UserID'])
        && !empty($_POST['MedicalHistory'])
        && !empty($_POST['CurrentStatus'])
        && !empty($_POST['Allergies'])
        && !empty($_POST['InsuranceDetails'])
        && !empty($_POST['AdmissionDate'])
    ) {
        $ID = filter_var(trim($_POST['ID']));
        $UserID = filter_var(trim($_POST['UserID']));
        $MedicalHistory = filter_var(trim($_POST['MedicalHistory']));
        $CurrentStatus = filter_var(trim($_POST['CurrentStatus']));
        $Allergies = filter_var(trim($_POST['Allergies']));
        $InsuranceDetails = filter_var(trim($_POST['InsuranceDetails']));
        $AdmissionDate = filter_var(trim($_POST['AdmissionDate']));

        $id = intval(trim($_GET['id']));
        $sql = "UPDATE patient SET ID = '$ID', UserID = '$UserID', MedicalHistory = '$MedicalHistory', CurrentStatus = '$CurrentStatus', Allergies = '$Allergies', InsuranceDetails = '$InsuranceDetails', AdmissionDate = '$AdmissionDate' WHERE id = $id";

        $rs = mysqli_query($con, $sql);

        if (mysqli_affected_rows($con) == 1) {
            $_SESSION['success_msg'] = 'Patient has been updated successfully';
            header('location:edit.php?id=' . $id);
            exit();
        } else {
            $error_msg[] = 'Unable to save patient';
        }
    } else {
        if (!isset($_POST['ID']) || empty($_POST['ID'])) {
            $error_msg[] = 'ID is required';
        }

        if (!isset($_POST['UserID']) || empty($_POST['UserID'])) {
            $error_msg[] = 'UserID is required';
        }

        if (!isset($_POST['MedicalHistory']) || empty($_POST['MedicalHistory'])) {
            $error_msg[] = 'MedicalHistory is required';
        }

        if (!isset($_POST['CurrentStatus']) || empty($_POST['CurrentStatus'])) {
            $error_msg[] = 'CurrentStatus is required';
        }

        if (!isset($_POST['Allergies']) || empty($_POST['Allergies'])) {
            $error_msg[] = 'Allergies is required';
        }

        if (!isset($_POST['InsuranceDetails']) || empty($_POST['InsuranceDetails'])) {
            $error_msg[] = 'InsuranceDetails is required';
        }

        if (!isset($_POST['AdmissionDate']) || empty($_POST['AdmissionDate'])) {
            $error_msg[] = 'AdmissionDate is required';
        }
    }
}

$id = intval(trim($_GET['id']));
$sql = "SELECT * FROM patient WHERE id = $id";
$rs = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($rs);
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient</title>
    <link rel="stylesheet" href="../public/main.css">
</head>

<body>
    <div class="container">
        <h2>Edit Patient</h2>

        <?php
        if (isset($_SESSION['success_msg'])) {
            echo '<div class="success-msg">' . $_SESSION['success_msg'] . '</div>';
            unset($_SESSION['success_msg']);
        }

        if (isset($error_msg) && !empty($error_msg)) {
            foreach ($error_msg as $error) {
                echo '<div class="error-msg">' . $error . '</div>';
            }
        }

        ?>
        <div class="align-center">
            <form action="" method="POST">
                <div class="form-group">
                    <label for="ID">ID</label>
                    <input type="text" name="ID" placeholder="Enter ID" id="ID" value="<?php echo $row['ID']; ?>">
                </div>
                <div class="form-group">
                    <label for="UserID">UserID</label>
                    <input type="text" name="UserID" placeholder="Enter UserID" id="UserID" value="<?php echo $row['UserID']; ?>">
                </div>
                <div class="form-group">
                    <label for="MedicalHistory">Medical History</label>
                    <textarea name="MedicalHistory" id="MedicalHistory"><?php echo $row['MedicalHistory']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="CurrentStatus">Current Status</label>
                    <input type="text" name="CurrentStatus" placeholder="Enter Current Status" id="CurrentStatus" value="<?php echo $row['CurrentStatus']; ?>">
                </div>
                <div class="form-group">
                    <label for="Allergies">Allergies</label>
                    <input type="text" name="Allergies" placeholder="Enter Allergies" id="Allergies" value="<?php echo $row['Allergies']; ?>">
                </div>
                <div class="form-group">
                    <label for="InsuranceDetails">Insurance Details</label>
                    <input type="text" name="InsuranceDetails" placeholder="Enter Insurance Details" id="InsuranceDetails" value="<?php echo $row['InsuranceDetails']; ?>">
                </div>
                <div class="form-group">
                    <label for="AdmissionDate">Admission Date</label>
                    <input type="date" name="AdmissionDate" id="AdmissionDate" value="<?php echo $row['AdmissionDate']; ?>">
                </div>
                <div class="form-group">
                    <button type="submit" name="submit">Submit</button>
                    <a href="index.php" class="back-link" style="float:right"><< Back</a>
                </div>
            </form>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</body>

</html>
