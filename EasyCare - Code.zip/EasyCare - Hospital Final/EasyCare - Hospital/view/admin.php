<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../public/main.css">
</head>
<body>
	<div class="container">
		<form>
			<h2>EasyCare Admin Login</h2>
            <label>Username</label>
            <br>
			<input type="text" name="username" placeholder="Username">
            <br>
            <label>Password</label>
            <br>
			<input type="password" name="password" placeholder="Password">
            <br>
            <center>
            <input type="submit" value="Login">
            </center>   
		</form>
	</div>
</body>
</html>
