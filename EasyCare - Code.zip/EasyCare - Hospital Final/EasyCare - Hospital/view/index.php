<?php
session_start();
require_once('../config/config.php');

if (isset($_GET['action'], $_GET['id']) && $_GET['action'] == 'delete') {
    $id = intval(trim($_GET['id']));

    $sql = 'delete from patient where id = ' . $id;
    $deleteRs = mysqli_query($con, $sql);

    if (mysqli_affected_rows($con) == 0) {
        $_SESSION['error_msg'] = 'Unable to delete record';
        header('location:index.php');
        exit();
    } else {
        $_SESSION['success_msg'] = 'Record has been deleted successfully';
        header('location:index.php');
        exit();
    }
}


$sql = 'select * from patient order by id desc';
$rs = mysqli_query($con, $sql);
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EasyCare</title>
    <link rel="stylesheet" href="../public/main.css">
</head>
<body>
    <div class="container">
        <h2>EasyCare Hospital</h2>
        <a href="create.php" class="add-new">Add New</a>

        <?php
        if (isset($_SESSION['success_msg'])) {
            echo '<div class="success-msg">' . $_SESSION['success_msg'] . '</div>';
            unset($_SESSION['success_msg']);
        }

        if (isset($_SESSION['error_msg'])) {
            echo '<div class="error-msg">' . $_SESSION['error_msg'] . '</div>';
            unset($_SESSION['error_msg']);
        }

        ?>

        <table class="table">
            <tr>
                <th>UserID</th>
                <th>Medical History</th>
                <th>CurrentStatus</th>
                <th>Allergies</th>
                <th>AdmissionDate</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($rs)) {
                ?>
                <tr>
                    <td> <?php echo $row['UserID'] ?> </td>
                    <td> <?php echo $row['MedicalHistory'] ?> </td>
                    <td> <?php echo $row['CurrentStatus'] ?> </td>
                    <td> <?php echo $row['Allergies'] ?> </td>
                    <td> <?php echo $row['AdmissionDate'] ?> </td>
                    <td>
                        <a href="edit.php?id=<?php echo $row['ID'] ?>">Edit</a> |
                        <a href="index.php?action=delete&id=<?php echo $row['ID'] ?>" class="delete-record">Delete</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $(".delete-record").click(function (e) {
                e.preventDefault();

                var confirmBox = confirm('Are you Sure?');

                if (confirmBox == true) {
                    var getHref = $(this).attr('href');
                    window.location.href = getHref;
                }


            });
        });
    </script>
</body>
</html>
