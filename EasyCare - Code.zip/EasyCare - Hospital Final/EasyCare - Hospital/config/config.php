<?php
// Database connection configuration
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'easycare2';

// Create a connection
$con = mysqli_connect($host, $username, $password, $database);

// Check if the connection was successful
if (!$con) {
    die('Database connection failed: ' . mysqli_connect_error());
}
