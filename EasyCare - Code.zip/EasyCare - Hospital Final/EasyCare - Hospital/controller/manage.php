<?php
session_start();
require_once '../config/config.php';




// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $patientID = $_POST['patientID'];
    $medications = $_POST['medications'];
    $dosage = $_POST['dosage'];
    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];

    // Insert the prescription into the database
    $query = "INSERT INTO prescription (PatientID, Medications, Dosage, StartDate, EndDate)
              VALUES ('$patientID', '$medications', '$dosage', '$startDate', '$endDate')";
    $result = mysqli_query($con, $query);

    if ($result) {
        // Prescription assigned successfully
        echo '<p>Prescription assigned successfully.</p>';
    } else {
        // Error assigning prescription
        echo '<p>Error assigning prescription. Please try again.</p>';
    }
}

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Prescriptions</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../public/main.css">
</head>
<body>
    <div class="container">
        <h2>Welcome, Dr</h2>
        <h2>Assign Prescription</h2>
        <form method="POST" action="../controller/manage.php">
            <label>Patient ID:</label>
            <input type="text" name="patientID" required>
            <label>Medications:</label>
            <input type="text" name="medications" required>
            <label>Dosage:</label>
            <input type="text" name="dosage" required>
            <label>Start Date:</label>
            <input type="date" name="startDate" required>
            <label>End Date:</label>
            <input type="date" name="endDate" required>
            <input type="submit" value="Assign Prescription">
        </form>
    </div>
</body>
</html>
